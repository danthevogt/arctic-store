import React from 'react';
import logo from './logo.svg';
import { Button } from 'react-bootstrap';
import { Navbar } from 'react-bootstrap';
import { Nav } from 'react-bootstrap';
import { NavDropdown } from 'react-bootstrap';
import { Link } from "react-router-dom";
import { Row } from "react-bootstrap";
import { Col } from "react-bootstrap";
import './App.scss';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";

export default function Top() {
  return (
    <Navbar expand="lg">
        <Link to="/">
            <Navbar.Brand>
                <img alt="Site Icon" src="\lab-logo.PNG" width="30px" /> Northwest Labs
            </Navbar.Brand>
        </Link>
    <Navbar.Toggle aria-controls="basic-navbar-nav" />
    <Navbar.Collapse id="basic-navbar-nav">
      <Nav className="mr-auto">
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/about" className="nav-link">About</Link>
        <Link to="/help" className="nav-link">Help</Link>
      </Nav>
      <Nav>
      <NavDropdown title="Welcome, Daniel" id="collasible-nav-dropdown">
            <NavDropdown.Item>My Account</NavDropdown.Item>
            <NavDropdown.Divider />
            <NavDropdown.Item>Logout</NavDropdown.Item>
        </NavDropdown>
    </Nav>
    </Navbar.Collapse>
  </Navbar>
    )
}