import React from 'react';
import './App.scss';

export default function Help() {
  return (
        <div>
          <h2>Help</h2>
          <h3>How may I help you today?</h3>
        </div>
  )
}