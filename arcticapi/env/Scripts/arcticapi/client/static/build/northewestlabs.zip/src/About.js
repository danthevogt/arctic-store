import React from 'react';
import './App.scss';

export default function About() {
  return (
        <div>
          <h2>Hello</h2>
          <h3>How are you?</h3>
        </div>
  )
}