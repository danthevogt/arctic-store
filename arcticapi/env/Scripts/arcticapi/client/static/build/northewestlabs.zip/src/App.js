import React from 'react';
import logo from './logo.svg';
import { Button } from 'react-bootstrap';
import { Row } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import './App.scss';
import Top from'./Top'
import Center from'./Center'
import Left from'./Left'
import Right from'./Right'
import Bottom from'./Bottom'
import About from'./About'
import Home from'./Home'
import Help from'./Help'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

export default function App(props) {
  return (
    <Router>
      <Container fluid>
        <Row>
          <Col className="top-bg">
            <Top />
          </Col>
        </Row>
        <Row>
          <Col className="left-bg">
            <Left />
          </Col>
          <Col xs={8} className="center-bg">
            <Switch>
              <Route path="/about">
                <About />
              </Route>
              <Route path="/help">
                <Help />
              </Route>
              <Route path="/">
                <Home />
              </Route>
            </Switch>
          </Col>          
          <Col className="right-bg">
            <Right />
          </Col>
        </Row>
        <Row className="bottom-bg">
          <Col>
            <Bottom />
          </Col>
        </Row>
      </Container>
    </Router>
  );
}