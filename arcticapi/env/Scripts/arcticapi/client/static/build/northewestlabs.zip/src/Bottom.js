import React from 'react';
import logo from './logo.svg';
import { Button } from 'react-bootstrap';
import { Row } from 'react-bootstrap';
import { Container } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import './App.scss';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

export default function Bottom() {
  return (
        <footer align="center">&copy; 2020 Northwest Labs</footer>
  )
}